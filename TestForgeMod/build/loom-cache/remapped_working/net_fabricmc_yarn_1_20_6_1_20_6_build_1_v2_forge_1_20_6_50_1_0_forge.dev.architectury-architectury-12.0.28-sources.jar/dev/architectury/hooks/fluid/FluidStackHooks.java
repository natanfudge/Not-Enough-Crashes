/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.fluid;

import dev.architectury.fluid.FluidStack;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_7225;
import net.minecraft.class_9129;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public class FluidStackHooks {
    private FluidStackHooks() {
    }
    
    @ExpectPlatform
    public static class_2561 getName(FluidStack stack) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static String getTranslationKey(FluidStack stack) {
        throw new AssertionError();
    }
    
    /**
     * Platform-specific FluidStack read.
     */
    @ExpectPlatform
    public static FluidStack read(class_9129 buf) {
        throw new AssertionError();
    }
    
    /**
     * Platform-specific FluidStack write.
     */
    @ExpectPlatform
    public static void write(FluidStack stack, class_9129 buf) {
        throw new AssertionError();
    }
    
    /**
     * Platform-specific FluidStack read.
     */
    @ExpectPlatform
    public static Optional<FluidStack> read(class_7225.class_7874 provider, class_2520 tag) {
        throw new AssertionError();
    }
    
    /**
     * Platform-specific FluidStack read.
     */
    @ExpectPlatform
    public static FluidStack readOptional(class_7225.class_7874 provider, class_2487 tag) {
        throw new AssertionError();
    }
    
    /**
     * Platform-specific FluidStack write.
     */
    @ExpectPlatform
    public static class_2520 write(class_7225.class_7874 provider, FluidStack stack, class_2520 tag) {
        throw new AssertionError();
    }
    
    /**
     * Platform-specific bucket amount.
     * Forge: 1000
     * Fabric: 81000
     */
    @ExpectPlatform
    public static long bucketAmount() {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    @Nullable
    public static class_1058 getStillTexture(@Nullable class_1920 level, @Nullable class_2338 pos, class_3610 state) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    @Nullable
    public static class_1058 getStillTexture(FluidStack stack) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    @Nullable
    public static class_1058 getStillTexture(class_3611 fluid) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    @Nullable
    public static class_1058 getFlowingTexture(@Nullable class_1920 level, @Nullable class_2338 pos, class_3610 state) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    @Nullable
    public static class_1058 getFlowingTexture(FluidStack stack) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    @Nullable
    public static class_1058 getFlowingTexture(class_3611 fluid) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    public static int getColor(@Nullable class_1920 level, @Nullable class_2338 pos, class_3610 state) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    public static int getColor(FluidStack stack) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    @Environment(EnvType.CLIENT)
    public static int getColor(class_3611 fluid) {
        throw new AssertionError();
    }
    
    /**
     * Returns the luminosity of the fluid.
     *
     * @param fluid the fluid
     * @param level the level, can be {@code null}
     * @param pos   the block position, can be {@code null}
     * @return the luminosity of the fluid, this ranges from 0 to 15
     */
    @ExpectPlatform
    public static int getLuminosity(FluidStack fluid, @Nullable class_1937 level, @Nullable class_2338 pos) {
        throw new AssertionError();
    }
    
    /**
     * Returns the luminosity of the fluid.
     *
     * @param fluid the fluid
     * @param level the level, can be {@code null}
     * @param pos   the block position, can be {@code null}
     * @return the luminosity of the fluid, this ranges from 0 to 15
     */
    @ExpectPlatform
    public static int getLuminosity(class_3611 fluid, @Nullable class_1937 level, @Nullable class_2338 pos) {
        throw new AssertionError();
    }
    
    /**
     * Returns the temperature of the fluid.
     * The temperature is in kelvin, for example, 300 kelvin is equal to room temperature.
     *
     * @param fluid the fluid
     * @param level the level, can be {@code null}
     * @param pos   the block position, can be {@code null}
     * @return the temperature of the fluid
     */
    @ExpectPlatform
    public static int getTemperature(FluidStack fluid, @Nullable class_1937 level, @Nullable class_2338 pos) {
        throw new AssertionError();
    }
    
    /**
     * Returns the temperature of the fluid.
     * The temperature is in kelvin, for example, 300 kelvin is equal to room temperature.
     *
     * @param fluid the fluid
     * @param level the level, can be {@code null}
     * @param pos   the block position, can be {@code null}
     * @return the temperature of the fluid
     */
    @ExpectPlatform
    public static int getTemperature(class_3611 fluid, @Nullable class_1937 level, @Nullable class_2338 pos) {
        throw new AssertionError();
    }
    
    /**
     * Returns the viscosity of the fluid. A lower viscosity means that the fluid will flow faster.
     * The default value is 1000 for water.
     *
     * @param fluid the fluid
     * @param level the level, can be {@code null}
     * @param pos   the block position, can be {@code null}
     * @return the viscosity of the fluid
     */
    @ExpectPlatform
    public static int getViscosity(FluidStack fluid, @Nullable class_1937 level, @Nullable class_2338 pos) {
        throw new AssertionError();
    }
    
    /**
     * Returns the viscosity of the fluid. A lower viscosity means that the fluid will flow faster.
     * The default value is 1000 for water.
     *
     * @param fluid the fluid
     * @param level the level, can be {@code null}
     * @param pos   the block position, can be {@code null}
     * @return the viscosity of the fluid
     */
    @ExpectPlatform
    public static int getViscosity(class_3611 fluid, @Nullable class_1937 level, @Nullable class_2338 pos) {
        throw new AssertionError();
    }
}
